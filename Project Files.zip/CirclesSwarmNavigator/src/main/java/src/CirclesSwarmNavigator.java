package src;

import java.util.*;
import java.awt.*;
import javax.swing.*;

public class CirclesSwarmNavigator extends Canvas{

	public CirclesSwarmNavigator(){

	}

	public static void main(String[] args){
		JFrame frame = new JFrame();
		frame.setSize(816,839);
		CirclesSwarmNavigator d = new CirclesSwarmNavigator();
		frame.add(d);
		frame.setVisible(true);
	}

	public void paint(Graphics g){
		double cutoffrad=1;//Radius below which the circles won't be plotted.
		ArrayList<Double> c00= new ArrayList<Double>();
		ArrayList<Double> c01= new ArrayList<Double>();
		ArrayList<Double> c02= new ArrayList<Double>();
		ArrayList<Double> c10= new ArrayList<Double>();
		ArrayList<Double> c11= new ArrayList<Double>();
		ArrayList<Double> c12= new ArrayList<Double>();
		ArrayList<Double> c20= new ArrayList<Double>();
		ArrayList<Double> c21= new ArrayList<Double>();
		ArrayList<Double> c22= new ArrayList<Double>();
		ArrayList<Double> KEY0 = new ArrayList<Double>();
		ArrayList<Double> KEY1 = new ArrayList<Double>();
		ArrayList<Double> KEY2 = new ArrayList<Double>();
		int colorNum=0;
		//{first,second,third},{x,y,z}
		Scanner alsoFax=new Scanner(System.in);
		double viewx,viewy,zoom;
		System.out.println("Which x value?");
		viewx=alsoFax.nextDouble();
		System.out.println("Which y value?");
		viewy=alsoFax.nextDouble();
		System.out.println("Which zoom value?");
		zoom=alsoFax.nextDouble();
		KEY0.add(400.0-viewx*400*zoom);
		KEY1.add(400.0-viewy*400*zoom);
		KEY2.add(-1/(400*zoom));
		dcircle(400-viewx*400*zoom,400-viewy*400*zoom,(int)(400*zoom),g);

		double cnew=0,normal,xnew=0,ynew=0,theta,theta2;int numeggs;

		while(KEY0.size()>0){
			c00.add(KEY0.get(0));
			c01.add(KEY1.get(0));
			c02.add(KEY2.get(0));
			c10.add(KEY0.get(0)+0.375/KEY2.get(0));
			c11.add(KEY1.get(0));
			c12.add(KEY2.get(0)*-8/5);
			c20.add(KEY0.get(0)-0.625/KEY2.get(0));
			c21.add(KEY1.get(0));
			c22.add(KEY2.get(0)*-8/3);
			

			if(KEY2.get(0)*-8/5<1/cutoffrad){
				KEY0.add(c10.get(0));
				KEY1.add(c11.get(0));
				KEY2.add(-c12.get(0));
			}

			if(KEY2.get(0)*-8/3<1/cutoffrad){
				KEY0.add(c20.get(0));
				KEY1.add(c21.get(0));
				KEY2.add(-c22.get(0));
			}

			colorNum++;
			g.setColor(getColor(colorNum));
			dcircle(c10.get(0),c11.get(0),1/c12.get(0),g);
			colorNum++;
			g.setColor(getColor(colorNum));
			dcircle(c20.get(0),c21.get(0),1/c22.get(0),g);
			colorNum++;
			g.setColor(getColor(colorNum));
			
			numeggs=0;
			//System.out.println(1/0);
			while(c00.size()>0){
				numeggs++;
				cnew=c02.get(0)+c12.get(0)+c22.get(0)+2*Math.sqrt(Math.abs(c02.get(0)*c12.get(0)+c22.get(0)*c12.get(0)+c02.get(0)*c22.get(0)));//probably correct
				theta=Math.acos(((1/c12.get(0)+1/c22.get(0))*(1/c12.get(0)+1/c22.get(0))+(1/c12.get(0)+(1/cnew))*(1/c12.get(0)+(1/cnew))-((1/cnew)+1/c22.get(0))*((1/cnew)+1/c22.get(0)))/
					(2*(1/c12.get(0)+1/c22.get(0))*(1/c12.get(0)+(1/cnew))));//This will break on undersides, I think.
					//But for now it seems legit.

				theta2=Math.acos((c20.get(0)-c10.get(0))/Math.sqrt((c20.get(0)-c10.get(0))*(c20.get(0)-c10.get(0))+(c21.get(0)-c11.get(0))*(c21.get(0)-c11.get(0))));//Correct
				if(c11.get(0)-c21.get(0)>0){
					theta2=-theta2;
				}
				if(c02.get(0)*Math.sin(Math.atan2(c01.get(0)-c11.get(0),c00.get(0)-c10.get(0))-theta2)<=0){//Where the issue is
					theta=-theta;
				}
				xnew=c10.get(0)+(1/c12.get(0)+(1/cnew))*Math.cos(theta+theta2);
				ynew=c11.get(0)+(1/c12.get(0)+(1/cnew))*Math.sin(theta+theta2);
				
				if(cnew<1/cutoffrad){
					dcircle(xnew,ynew,1/cnew,g);
					colorNum++;
					g.setColor(getColor(colorNum));
					/*System.out.println("x: "+xnew);
					System.out.println("y: "+ynew);
					System.out.println("r: "+1/cnew);*/
					dcircle(xnew,ynew,1/cnew,g);
					colorNum++;
					g.setColor(getColor(colorNum));
					
					c00.add(c00.get(0));
					c01.add(c01.get(0));
					c02.add(c02.get(0));
					c10.add(c10.get(0));
					c11.add(c11.get(0));
					c12.add(c12.get(0));
					c20.add(xnew);
					c21.add(ynew);
					c22.add(cnew);

					c00.add(c00.get(0));
					c01.add(c01.get(0));
					c02.add(c02.get(0));
					c10.add(c20.get(0));
					c11.add(c21.get(0));
					c12.add(c22.get(0));
					c20.add(xnew);
					c21.add(ynew);
					c22.add(cnew);

					c00.add(c10.get(0));
					c01.add(c11.get(0));
					c02.add(c12.get(0));
					c10.add(c20.get(0));
					c11.add(c21.get(0));
					c12.add(c22.get(0));
					c20.add(xnew);
					c21.add(ynew);
					c22.add(cnew);

					KEY0.add(xnew);
					KEY1.add(ynew);
					KEY2.add(-cnew);

					if(c02.get(0)*Math.sin(Math.atan2(c01.get(0)-c11.get(0),c00.get(0)-c10.get(0))-theta2)==0){
						theta=-theta;
						xnew=c10.get(0)+(1/c12.get(0)+(1/cnew))*Math.cos(theta+theta2);
						ynew=c11.get(0)+(1/c12.get(0)+(1/cnew))*Math.sin(theta+theta2);
						dcircle(xnew,ynew,1/cnew,g);
						colorNum++;
						g.setColor(getColor(colorNum));

						c00.add(c00.get(0));
						c01.add(c01.get(0));
						c02.add(c02.get(0));
						c10.add(c10.get(0));
						c11.add(c11.get(0));
						c12.add(c12.get(0));
						c20.add(xnew);
						c21.add(ynew);
						c22.add(cnew);

						c00.add(c00.get(0));
						c01.add(c01.get(0));
						c02.add(c02.get(0));
						c10.add(c20.get(0));
						c11.add(c21.get(0));
						c12.add(c22.get(0));
						c20.add(xnew);
						c21.add(ynew);
						c22.add(cnew);

						c00.add(c10.get(0));
						c01.add(c11.get(0));
						c02.add(c12.get(0));
						c10.add(c20.get(0));
						c11.add(c21.get(0));
						c12.add(c22.get(0));
						c20.add(xnew);
						c21.add(ynew);
						c22.add(cnew);

						KEY0.add(xnew);
						KEY1.add(ynew);
						KEY2.add(-cnew);
					}
				}
				c00.remove(0);
				c01.remove(0);
				c02.remove(0);
				c10.remove(0);
				c11.remove(0);
				c12.remove(0);
				c20.remove(0);
				c21.remove(0);
				c22.remove(0);

				//alsoFax.nextLine();

				colorNum++;
				g.setColor(getColor(colorNum));
			}
			
			KEY0.remove(0);
			KEY1.remove(0);
			KEY2.remove(0);
		}
		System.out.println("Done.");
	}

	public Color getColor(int x){
		return (new Color((x*141)%255,(x*31)%255,(x+7)%255));
	}

	public void circle(int x, int y, int r, Graphics g){
		g.fillOval(x-r,800-y-r,r*2,r*2);
	}


	public void dcircle(double x, double y, double r, Graphics g){
		circle((int)x,(int)y,(int)r,g);
	}
}
